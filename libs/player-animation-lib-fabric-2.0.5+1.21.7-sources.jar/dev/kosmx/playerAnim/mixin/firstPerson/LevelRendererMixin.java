package dev.kosmx.playerAnim.mixin.firstPerson;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import dev.kosmx.playerAnim.api.firstPerson.FirstPersonMode;
import dev.kosmx.playerAnim.impl.IAnimatedPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4604;
import net.minecraft.class_761;

@Mixin(class_761.class)
public class LevelRendererMixin {


    // @Redirect(at = @At(target = "Lnet/minecraft/client/Camera;isDetached()Z")) is forbidden

    @ModifyExpressionValue(method = "collectVisibleEntities", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Camera;isDetached()Z"))
    private boolean fakeThirdPersonMode(boolean original, class_4184 camera, class_4604 frustum, List<class_1297> list) {

        if (camera.method_19331() instanceof IAnimatedPlayer player && player.playerAnimator_getAnimation().getFirstPersonMode() == FirstPersonMode.THIRD_PERSON_MODEL) {
            FirstPersonMode.setFirstPersonPass(!camera.method_19333() && (!(camera.method_19331() instanceof class_1309) || !((class_1309)camera.method_19331()).method_6113())); // this will cause a lot of pain
            return true;
        }
        return original;
    }

    @Inject(method = "renderEntity", at = @At("TAIL"))
    private void dontRenderEntity_End(class_1297 entity, double cameraX, double cameraY, double cameraZ,
                                      float tickDelta, class_4587 matrices, class_4597 vertexConsumers, CallbackInfo ci) {
        class_4184 camera = class_310.method_1551().field_1773.method_19418();
        if (entity == camera.method_19331()) {
            FirstPersonMode.setFirstPersonPass(false); // Unmark this render cycle
        }
    }
}
