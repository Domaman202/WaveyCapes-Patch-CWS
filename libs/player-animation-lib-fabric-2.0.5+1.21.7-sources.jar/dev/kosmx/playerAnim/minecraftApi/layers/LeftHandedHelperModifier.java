package dev.kosmx.playerAnim.minecraftApi.layers;

import dev.kosmx.playerAnim.api.layered.modifier.MirrorModifier;
import net.minecraft.class_1306;
import net.minecraft.class_1657;

/**
 * Left-handedness helper
 * If enabled, automatically mirror all animation if player is left-handed
 */
public class LeftHandedHelperModifier extends MirrorModifier {
    private final class_1657 player;

    public LeftHandedHelperModifier(class_1657 player) {
        this.player = player;
    }

    @Override
    public boolean isEnabled() {
        return super.isEnabled() && player.method_6068() == class_1306.field_6182;
    }
}
