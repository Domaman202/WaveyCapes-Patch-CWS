package dev.kosmx.playerAnim.minecraftApi.codec;

import dev.kosmx.playerAnim.api.IPlayable;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.io.OutputStream;
import net.minecraft.class_2960;

@FunctionalInterface
public interface AnimationEncoder<T extends IPlayable> {
    void encode(@NotNull OutputStream output, @NotNull class_2960 location, @NotNull T animation) throws IOException;
}
